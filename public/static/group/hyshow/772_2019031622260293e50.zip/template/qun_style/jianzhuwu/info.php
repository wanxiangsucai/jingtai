<?php 

return [
	'name'=>'建筑物',
    'sort'=>'其他行业',
	'money'=>0,//收费金额
];